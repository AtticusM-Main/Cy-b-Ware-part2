# Cy-B-Ware — Part 2: GUI Edition 🛡️

A WPF-based Cybersecurity Awareness Chatbot extending Part 1 with a full graphical interface, sentiment detection, memory, keyword recognition, random responses, and conversation flow.

---

## ✅ Part 2 Requirements Checklist

| # | Requirement | Status |
|---|-------------|--------|
| 1 | **GUI Design & Implementation (WPF)** | ✅ |
| 1a | All Part 1 topics translated to GUI | ✅ |
| 1b | Neat, user-friendly design with colours & spacing | ✅ |
| 1c | ASCII art → WPF header logo with shield icon | ✅ |
| 1d | Voice greeting (greeting.wav) plays on startup | ✅ |
| 2 | **Keyword Recognition** (password, scam, privacy + more) | ✅ |
| 3 | **Random Responses** (3 per topic using Lists) | ✅ |
| 4 | **Conversation Flow** (tell me more / explain more / give me another tip) | ✅ |
| 5 | **Memory & Recall** (name, favourite topic, last topic, topic frequency) | ✅ |
| 6 | **Sentiment Detection** (worried, curious, frustrated, happy) | ✅ |
| 7 | **Error Handling** (default response for unknown input, no crashes) | ✅ |
| 8 | **Code Optimisation** (OOP, dictionaries/lists, classes, methods) | ✅ |

---

## 🚀 How to Run

### Prerequisites
- Windows 10/11
- [.NET 8 SDK](https://dotnet.microsoft.com/download/dotnet/8.0) (or .NET 9)
- Visual Studio 2022 (Community or higher) **with the .NET desktop development workload**

### Steps
1. Open `CyBWare-Part2.sln` in Visual Studio 2022.
2. Set **CyBWare-Part2** as the startup project.
3. Press **F5** or click **Start**.
4. (Optional) Place `greeting.wav` in the output folder (`bin\Debug\net8.0-windows\`) to enable the voice greeting.

---

## 🏗️ Project Structure

```
CyBWare-Part2/
├── CyBWare-Part2.sln
└── CyBWare-Part2/
    ├── App.xaml / App.xaml.cs          — Application entry point & global styles
    ├── MainWindow.xaml                  — Full GUI layout (WPF XAML)
    ├── MainWindow.xaml.cs               — GUI interaction logic & event handlers
    ├── Models/
    │   ├── ChatMessage.cs               — Message model (INotifyPropertyChanged)
    │   └── UserMemory.cs                — User memory store (name, topics, favourites)
    └── Services/
        ├── ChatbotEngine.cs             — Core chatbot logic (keywords, random responses, flow)
        └── SentimentDetector.cs         — Sentiment analysis (worried/curious/frustrated/happy)
```

---

## 🎨 GUI Features

- **Dark cybersecurity theme** — deep navy/charcoal background, cyan accents, green highlights
- **Chat bubbles** — distinct bot (cyan) and user (green) bubbles with avatars and timestamps
- **Sidebar** — live memory panel, topic stats with hit counters, rotating "Did you know?" tips
- **Quick-topic buttons** — one-click access to all 8 cybersecurity topics
- **Sentiment badge** — real-time mood indicator in the header
- **Placeholder text** — input field shows hint text when empty
- **Auto-scroll** — chat always scrolls to the latest message

---

## 💬 Conversation Examples

**Keyword recognition:**
> User: "Tell me about password safety."
> Bot: *(Recognises "password" → picks randomly from 3 response variants)*

**Sentiment detection:**
> User: "I'm worried about online scams."
> Bot: "It's completely understandable to feel that way... *(then shares scam tips)*"

**Memory recall:**
> User: "What do you know about me?"
> Bot: "Here's what I know about you, [Name]: Name, Favourite topic, Last topic, Topic history..."

**Conversation flow:**
> User: "Tell me more" / "Give me another tip" / "Explain more"
> Bot: *(Continues on the last discussed topic without requiring a new keyword)*

---

## 🗂️ OOP Design (Requirement 8)

| Class | Responsibility |
|-------|----------------|
| `ChatbotEngine` | All response logic; uses `List<string>` banks per topic, `Dictionary` for memory |
| `UserMemory` | Encapsulates user state (name, topics, frequencies) |
| `SentimentDetector` | Static utility for keyword-based sentiment classification |
| `ChatMessage` | Data model with `INotifyPropertyChanged` for WPF binding |
| `MessageTemplateSelector` | WPF `DataTemplateSelector` for conditional bubble rendering |

---

## 📝 Notes

- `greeting.wav` is loaded from the application's output directory. Place your WAV file there to enable audio.
- The app handles all unexpected or empty inputs gracefully with a helpful default response (Requirement 7).
- All Part 1 topics (password, phishing, safe browsing, 2FA, malware, social engineering) are fully preserved and extended with 3 random response variants each.
- Additional topics added for Part 2: **Privacy** and **Scams**.
