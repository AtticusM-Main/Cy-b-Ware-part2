using System.Windows;

namespace CyBWare
{
    public partial class App : Application { }
}
