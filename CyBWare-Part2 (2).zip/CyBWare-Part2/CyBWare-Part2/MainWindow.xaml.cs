using System.Collections.ObjectModel;
using System.Media;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using CyBWare.Models;
using CyBWare.Services;

namespace CyBWare
{
    public partial class MainWindow : Window
    {
        // ── State ─────────────────────────────────────────────────────────────
        private readonly ChatbotEngine _engine = new();
        private readonly ObservableCollection<ChatMessage> _messages = new();
        private bool _chatStarted = false;

        // Placeholder text support
        private const string PlaceholderText = "Type a message... (Press Enter to send)";
        private bool _isPlaceholder = true;

        // ── Rotating "did you know" tips ──────────────────────────────────────
        private static readonly string[] _tips =
        {
            "95% of cybersecurity breaches are caused by human error.",
            "A data breach costs companies an average of $4.45M in 2023.",
            "Ransomware attacks occur every 11 seconds globally.",
            "Only 5% of companies properly protect all their data.",
            "Phishing accounts for 36% of all data breaches.",
            "Using a password manager reduces breach risk by 80%.",
            "Enabling 2FA blocks 99.9% of automated account attacks.",
            "The average person reuses the same password 14 times."
        };
        private readonly Random _rng = new();

        // ── Constructor ───────────────────────────────────────────────────────
        public MainWindow()
        {
            InitializeComponent();
            MessageList.DataContext = _messages;
            MessageList.ItemsSource = _messages;
            ShowPlaceholder();
            SetRandomTip();
            TryPlayGreeting();
        }

        // ── Greeting audio (from Part 1) ──────────────────────────────────────
        private static void TryPlayGreeting()
        {
            try
            {
                string wavPath = System.IO.Path.Combine(
                    AppDomain.CurrentDomain.BaseDirectory, "greeting.wav");

                if (System.IO.File.Exists(wavPath))
                {
                    var player = new SoundPlayer(wavPath);
                    player.Play();
                }
            }
            catch { /* Silently ignore if no audio file */ }
        }

        // ── Name setup ────────────────────────────────────────────────────────
        private void NameInput_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter) StartChat_Click(sender, e);
        }

        private void StartChat_Click(object sender, RoutedEventArgs e)
        {
            string name = NameInput.Text.Trim();
            if (string.IsNullOrWhiteSpace(name))
            {
                NameInput.BorderBrush = (SolidColorBrush)FindResource("WarningRed");
                NameInput.Focus();
                return;
            }

            _engine.Memory.Name = name;
            _chatStarted = true;

            // Hide name bar
            NameSetupBar.Visibility = Visibility.Collapsed;

            // Update sidebar memory
            UpdateMemorySidebar();

            // Post welcome message from bot
            AddBotMessage(
                $"Welcome to Cy-B-Ware, {name}! 🛡️\n\n" +
                "I'm your cybersecurity awareness companion. I'm here to help you stay safe online.\n\n" +
                "You can ask me about:\n" +
                "🔑 Password Safety  •  🎣 Phishing  •  ⚠️ Scams\n" +
                "🕵️ Privacy  •  🦠 Malware  •  🌐 Safe Browsing\n" +
                "🔐 Two-Factor Auth  •  🎭 Social Engineering\n\n" +
                "Or just type anything — I understand natural language! " +
                "Use the quick buttons below for fast access.");

            SetStatus($"🟢 Chat started — Welcome, {name}!");
            UserInput.Focus();
        }

        // ── Message sending ───────────────────────────────────────────────────
        private void SendButton_Click(object sender, RoutedEventArgs e) => SendMessage();

        private void UserInput_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter && !e.IsRepeat) SendMessage();
        }

        private void SendMessage()
        {
            if (!_chatStarted)
            {
                NameInput.Focus();
                return;
            }

            string text = _isPlaceholder ? string.Empty : UserInput.Text.Trim();

            if (string.IsNullOrWhiteSpace(text))
            {
                SetStatus("⚠️  Please type a message first.");
                return;
            }

            // Post user message
            AddUserMessage(text);
            ClearInput();

            // Exit command
            if (text.Equals("exit", StringComparison.OrdinalIgnoreCase) ||
                text.Equals("quit", StringComparison.OrdinalIgnoreCase) ||
                text.Equals("bye", StringComparison.OrdinalIgnoreCase))
            {
                var (farewell, _, _) = _engine.GetResponse(text);
                AddBotMessage(farewell);
                SetStatus("👋 Goodbye!");
                return;
            }

            // Get bot response
            SetStatus("🤔 Cy-B-Ware is thinking...");
            var (response, sentiment, topicKey) = _engine.GetResponse(text);

            // Store last response for follow-ups
            _engine.Memory.LastBotResponse = response;

            // Update sentiment badge
            UpdateSentimentBadge(sentiment);

            // Post bot response
            AddBotMessage(response, sentiment);

            // Update sidebar
            UpdateMemorySidebar();
            SetRandomTip();
            SetStatus("🟢 Ready");
        }

        // ── Quick-topic buttons ───────────────────────────────────────────────
        private void TopicBtn_Click(object sender, RoutedEventArgs e)
        {
            if (!_chatStarted) { NameInput.Focus(); return; }
            if (sender is Button btn && btn.Tag is string tag)
            {
                UserInput.Text = tag;
                _isPlaceholder = false;
                UserInput.Foreground = (SolidColorBrush)FindResource("TextWhite");
                SendMessage();
            }
        }

        // ── Clear chat ────────────────────────────────────────────────────────
        private void ClearChat_Click(object sender, RoutedEventArgs e)
        {
            _messages.Clear();
            SetStatus("🗑  Chat cleared.");
            if (_chatStarted)
                AddBotMessage($"Chat cleared! I still remember who you are, {_engine.Memory.Name}. What would you like to know?");
        }

        // ── Helpers ───────────────────────────────────────────────────────────
        private void AddBotMessage(string text, SentimentType sentiment = SentimentType.Neutral)
        {
            _messages.Add(new ChatMessage
            {
                Sender    = MessageSender.Bot,
                Text      = text,
                Sentiment = sentiment
            });
            ScrollToBottom();
        }

        private void AddUserMessage(string text)
        {
            _messages.Add(new ChatMessage
            {
                Sender = MessageSender.User,
                Text   = text
            });
            ScrollToBottom();
        }

        private void ScrollToBottom()
        {
            Dispatcher.InvokeAsync(() =>
            {
                ChatScroll.ScrollToBottom();
            }, System.Windows.Threading.DispatcherPriority.Loaded);
        }

        private void SetStatus(string text) => StatusText.Text = text;

        private void UpdateSentimentBadge(SentimentType sentiment)
        {
            var (emoji, label, color) = sentiment switch
            {
                SentimentType.Worried    => ("😟", "Worried",    "#FFD700"),
                SentimentType.Curious    => ("🤔", "Curious",    "#00E5FF"),
                SentimentType.Frustrated => ("😤", "Frustrated", "#FF4444"),
                SentimentType.Happy      => ("😊", "Happy",      "#39FF14"),
                _                        => ("😐", "Neutral",    "#8B949E")
            };

            SentimentText.Text = $"{emoji} {label}";
            SentimentText.Foreground = new SolidColorBrush(
                (Color)ColorConverter.ConvertFromString(color));
            SentimentBadge.BorderBrush = new SolidColorBrush(
                (Color)ColorConverter.ConvertFromString(color));
        }

        private void UpdateMemorySidebar()
        {
            var mem = _engine.Memory;
            MemoryName.Text = mem.Name;
            MemoryFav.Text  = mem.FavouriteTopic ?? "—";
            MemoryLast.Text = mem.LastTopic ?? "—";

            // Update stats
            StatsPanel.ItemsSource = mem.TopicFrequency
                .OrderByDescending(kv => kv.Value)
                .ToList();
        }

        private void SetRandomTip()
        {
            TipText.Text = _tips[_rng.Next(_tips.Length)];
        }

        // ── Placeholder text behaviour ────────────────────────────────────────
        private void ShowPlaceholder()
        {
            UserInput.Text = PlaceholderText;
            UserInput.Foreground = (SolidColorBrush)FindResource("TextDim");
            _isPlaceholder = true;
        }

        private void ClearInput()
        {
            ShowPlaceholder();
        }

        private void UserInput_GotFocus(object sender, RoutedEventArgs e)
        {
            if (_isPlaceholder)
            {
                UserInput.Text = string.Empty;
                UserInput.Foreground = (SolidColorBrush)FindResource("TextWhite");
                _isPlaceholder = false;
            }
        }

        private void UserInput_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(UserInput.Text))
            {
                ShowPlaceholder();
            }
        }
    }

    // ── DataTemplate selector ─────────────────────────────────────────────────
    public class MessageTemplateSelector : DataTemplateSelector
    {
        public DataTemplate? BotTemplate    { get; set; }
        public DataTemplate? UserTemplate   { get; set; }
        public DataTemplate? SystemTemplate { get; set; }

        public override DataTemplate? SelectTemplate(object item, DependencyObject container)
        {
            if (item is ChatMessage msg)
            {
                return msg.Sender switch
                {
                    MessageSender.Bot    => BotTemplate,
                    MessageSender.User   => UserTemplate,
                    MessageSender.System => SystemTemplate,
                    _ => BotTemplate
                };
            }
            return base.SelectTemplate(item, container);
        }
    }
}
