namespace CyBWare.Models
{
    /// <summary>
    /// Stores persistent details about the user so the chatbot can personalise responses.
    /// </summary>
    public class UserMemory
    {
        public string Name { get; set; } = "Friend";

        // Favourite / most-discussed cybersecurity topic
        public string? FavouriteTopic { get; set; }

        // Last topic discussed so the bot can handle follow-ups
        public string? LastTopic { get; set; }

        // Last bot response text for "tell me more" / "explain more" handling
        public string? LastBotResponse { get; set; }

        // Track how many times the user has asked about a topic
        public Dictionary<string, int> TopicFrequency { get; set; } = new();

        /// <summary>Records a topic hit and updates the favourite topic.</summary>
        public void RecordTopic(string topic)
        {
            if (!TopicFrequency.ContainsKey(topic))
                TopicFrequency[topic] = 0;
            TopicFrequency[topic]++;
            LastTopic = topic;

            // Favourite = the most-asked topic
            FavouriteTopic = TopicFrequency.MaxBy(kv => kv.Value).Key;
        }
    }
}
