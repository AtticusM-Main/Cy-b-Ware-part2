using System.ComponentModel;

namespace CyBWare.Models
{
    public enum MessageSender { Bot, User, System }
    public enum SentimentType { Neutral, Worried, Curious, Frustrated, Happy }

    public class ChatMessage : INotifyPropertyChanged
    {
        private string _text = string.Empty;

        public MessageSender Sender { get; set; }
        public SentimentType Sentiment { get; set; }
        public string Timestamp { get; set; } = DateTime.Now.ToString("HH:mm");

        public string Text
        {
            get => _text;
            set { _text = value; OnPropertyChanged(nameof(Text)); }
        }

        public bool IsBot    => Sender == MessageSender.Bot;
        public bool IsUser   => Sender == MessageSender.User;
        public bool IsSystem => Sender == MessageSender.System;

        public event PropertyChangedEventHandler? PropertyChanged;
        protected void OnPropertyChanged(string name) =>
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }
}
