using CyBWare.Models;

namespace CyBWare.Services
{
    /// <summary>
    /// Detects simple sentiment from user input so the bot can respond empathetically.
    /// </summary>
    public static class SentimentDetector
    {
        private static readonly string[] WorriedKeywords =
        {
            "worried", "scared", "afraid", "anxious", "nervous", "fear", "terrified",
            "unsafe", "at risk", "help me", "i don't know what to do", "not sure",
            "panicking", "panic", "concerned", "concern"
        };

        private static readonly string[] CuriousKeywords =
        {
            "curious", "wonder", "how does", "what is", "tell me", "explain",
            "why", "how", "what", "interested", "learn", "want to know"
        };

        private static readonly string[] FrustratedKeywords =
        {
            "frustrated", "annoyed", "angry", "this is stupid", "useless",
            "doesn't work", "not helping", "confused", "confusing",
            "don't understand", "cant understand", "can't figure", "ugh", "argh"
        };

        private static readonly string[] HappyKeywords =
        {
            "great", "awesome", "thanks", "thank you", "helpful", "love it",
            "nice", "cool", "perfect", "excellent", "good", "amazing"
        };

        public static SentimentType Detect(string input)
        {
            string lower = input.ToLower();

            if (WorriedKeywords.Any(k => lower.Contains(k)))    return SentimentType.Worried;
            if (FrustratedKeywords.Any(k => lower.Contains(k))) return SentimentType.Frustrated;
            if (HappyKeywords.Any(k => lower.Contains(k)))      return SentimentType.Happy;
            if (CuriousKeywords.Any(k => lower.Contains(k)))    return SentimentType.Curious;

            return SentimentType.Neutral;
        }

        /// <summary>Returns an empathetic opening line based on detected sentiment.</summary>
        public static string GetSentimentPrefix(SentimentType sentiment, string userName) =>
            sentiment switch
            {
                SentimentType.Worried =>
                    $"It's completely understandable to feel that way, {userName}. " +
                    "Cybersecurity can feel overwhelming, but I'm here to help. ",

                SentimentType.Frustrated =>
                    $"I hear you, {userName} — let me try to make this clearer. ",

                SentimentType.Happy =>
                    $"Love the energy, {userName}! 😊 ",

                SentimentType.Curious =>
                    $"Great question, {userName}! Here's what you need to know. ",

                _ => string.Empty
            };
    }
}
