using CyBWare.Models;

namespace CyBWare.Services
{
    /// <summary>
    /// Core chatbot engine: keyword recognition, random responses,
    /// conversation flow, memory recall, sentiment detection, and error handling.
    /// All Part 1 topics are preserved and extended for Part 2.
    /// </summary>
    public class ChatbotEngine
    {
        // ── Memory ────────────────────────────────────────────────────────────
        public UserMemory Memory { get; } = new();

        private readonly Random _rng = new();

        // ── Random response banks (Requirement 3) ────────────────────────────
        private readonly List<string> _passwordResponses = new()
        {
            "Use at least 12 characters — longer is stronger.\n" +
            "• Mix uppercase, lowercase, numbers, and symbols.\n" +
            "• Never reuse passwords across different sites.\n" +
            "• Use a trusted password manager like Bitwarden or 1Password.\n" +
            "• Enable two-factor authentication wherever possible.",

            "Avoid names, birthdays, or dictionary words in your password.\n" +
            "• A passphrase like 'Coffee!Rain#42Mountain' is strong AND memorable.\n" +
            "• Change passwords immediately if you suspect a breach.\n" +
            "• Never share your password with anyone — not even IT support.",

            "Password managers are your best friend!\n" +
            "• They generate, store, and auto-fill strong unique passwords.\n" +
            "• Top picks: Bitwarden (free), 1Password, or Dashlane.\n" +
            "• Never store passwords in plain-text files or sticky notes."
        };

        private readonly List<string> _phishingResponses = new()
        {
            "Phishing is one of the top cyber threats!\n" +
            "• Check the sender's email address carefully — look for misspellings.\n" +
            "• Be suspicious of urgent language like 'Act now!' or 'Your account is closed!'.\n" +
            "• Hover over links to see the real URL before clicking.\n" +
            "• Legitimate organisations NEVER ask for your password via email.",

            "Received a suspicious email? Here's what to do:\n" +
            "1. Do NOT click any links or open attachments.\n" +
            "2. Report it to your IT department or email provider.\n" +
            "3. Delete it immediately.\n" +
            "Remember: When in doubt, throw it out!",

            "Watch out for these phishing red flags:\n" +
            "• Generic greetings like 'Dear Customer' instead of your name.\n" +
            "• Requests for sensitive info via email or SMS.\n" +
            "• URLs that look almost-right (e.g. 'paypa1.com' vs 'paypal.com').\n" +
            "• Unexpected attachments, especially .zip or .exe files."
        };

        private readonly List<string> _scamResponses = new()
        {
            "Scammers can be very convincing. Let me share some tips to help you stay safe:\n" +
            "• Be sceptical of unsolicited calls, texts, or emails asking for money or info.\n" +
            "• No legitimate lottery or prize asks you to pay fees upfront.\n" +
            "• Verify requests by contacting the organisation through official channels.",

            "Common scam types to watch for:\n" +
            "• Romance scams — building trust online before asking for money.\n" +
            "• Tech support scams — fake alerts claiming your PC is infected.\n" +
            "• Invoice scams — fake bills sent to businesses.\n" +
            "• Cryptocurrency scams — 'guaranteed returns' are always red flags.",

            "If you think you've been scammed:\n" +
            "1. Stop all contact with the scammer immediately.\n" +
            "2. Report to your bank if money was involved.\n" +
            "3. Report to the South African Police Service (SAPS) and the SAFPS.\n" +
            "4. Change any compromised passwords right away."
        };

        private readonly List<string> _privacyResponses = new()
        {
            "Protecting your privacy online starts with awareness:\n" +
            "• Review app permissions — does a flashlight app really need your contacts?\n" +
            "• Use a private browsing mode or a VPN to reduce tracking.\n" +
            "• Opt out of data sharing in account settings where possible.",

            "Your digital footprint matters!\n" +
            "• Limit what personal info you share on social media.\n" +
            "• Use different email addresses for important accounts vs newsletters.\n" +
            "• Regularly audit which third-party apps have access to your accounts.",

            "Privacy tip: check your privacy settings today!\n" +
            "• Facebook, Google, Instagram all have dedicated privacy dashboards.\n" +
            "• Enable 'Do Not Track' in your browser.\n" +
            "• Consider using privacy-focused alternatives like DuckDuckGo or Brave."
        };

        private readonly List<string> _malwareResponses = new()
        {
            "Malware protection essentials:\n" +
            "• Install reputable antivirus software (Windows Defender is a solid free option).\n" +
            "• Never download software from unofficial or untrusted sources.\n" +
            "• Back up your data regularly — ransomware can lock your files.\n" +
            "• Be cautious of USB drives from unknown sources.",

            "If you think you have malware:\n" +
            "1. Disconnect from the internet immediately.\n" +
            "2. Run a full antivirus scan in Safe Mode.\n" +
            "3. Change all passwords from a different, clean device.\n" +
            "4. Check your bank accounts for unauthorised transactions.",

            "Types of malware you should know:\n" +
            "• Ransomware — encrypts your files and demands payment.\n" +
            "• Spyware — secretly monitors your activity.\n" +
            "• Trojans — disguise themselves as legitimate software.\n" +
            "• Keyloggers — record everything you type, including passwords."
        };

        private readonly List<string> _browsingResponses = new()
        {
            "Safe browsing tips:\n" +
            "• Always check for 'https://' and a padlock icon before entering personal info.\n" +
            "• Keep your browser and extensions updated — patches fix security holes.\n" +
            "• Use a reputable ad blocker (uBlock Origin is excellent).\n" +
            "• Avoid public Wi-Fi for banking or shopping without a VPN.",

            "Browser security settings to check right now:\n" +
            "• Enable automatic updates for your browser.\n" +
            "• Disable unnecessary browser extensions.\n" +
            "• Clear cookies and cache regularly.\n" +
            "• Enable 'Safe Browsing' in Chrome or 'Enhanced Tracking Protection' in Firefox.",

            "Public Wi-Fi safety tips:\n" +
            "• Treat every public Wi-Fi as potentially hostile.\n" +
            "• Use a VPN (ProtonVPN, Mullvad) to encrypt your connection.\n" +
            "• Avoid accessing banking or sensitive accounts on public networks.\n" +
            "• Turn off auto-connect to Wi-Fi networks."
        };

        private readonly List<string> _twoFaResponses = new()
        {
            "Two-Factor Authentication (2FA) is one of the best defences!\n" +
            "• It requires a second proof of identity beyond just your password.\n" +
            "• Use an authenticator app (Google Authenticator, Authy) over SMS when possible.\n" +
            "• Enable 2FA on email, banking, and social media accounts first.",

            "Why SMS-based 2FA can be risky:\n" +
            "• SIM-swapping attacks can let criminals intercept your SMS codes.\n" +
            "• Prefer authenticator apps or hardware security keys (e.g. YubiKey).\n" +
            "• Even SMS-based 2FA is still much better than no 2FA at all!",

            "Setting up 2FA step by step:\n" +
            "1. Download an authenticator app like Authy or Microsoft Authenticator.\n" +
            "2. Go to your account's security settings.\n" +
            "3. Choose 'Authenticator App' as your 2FA method.\n" +
            "4. Scan the QR code and store your backup codes safely."
        };

        private readonly List<string> _socialEngResponses = new()
        {
            "Social engineering is the art of manipulating people, not systems.\n" +
            "• Attackers may impersonate colleagues, banks, or IT support.\n" +
            "• Always verify identities before sharing sensitive information.\n" +
            "• It's okay to hang up and call back on an official number.",

            "Common social engineering tactics:\n" +
            "• Pretexting — fabricating a scenario to extract info (e.g. 'I'm from IT support').\n" +
            "• Baiting — leaving infected USB drives for curious people to plug in.\n" +
            "• Quid pro quo — offering help in exchange for information.\n" +
            "• No legitimate company will pressure you to act within seconds.",

            "How to defend against social engineering:\n" +
            "• Adopt a 'trust but verify' mindset for all unexpected requests.\n" +
            "• Implement clear security policies in your workplace.\n" +
            "• Train yourself and colleagues to recognise manipulation tactics.\n" +
            "• If something feels off, it probably is — trust your instincts."
        };

        // ── Keyword → (topic-key, response-bank) map ─────────────────────────
        private string Pick(List<string> list) => list[_rng.Next(list.Count)];

        // ── Public entry point ────────────────────────────────────────────────
        public (string response, SentimentType sentiment, string? topicKey) GetResponse(string userInput)
        {
            if (string.IsNullOrWhiteSpace(userInput))
                return ("I didn't catch that — could you type something?",
                        SentimentType.Neutral, null);

            string lower = userInput.ToLower();
            SentimentType sentiment = SentimentDetector.Detect(lower);
            string sentimentPrefix = SentimentDetector.GetSentimentPrefix(sentiment, Memory.Name);

            // ── Exit ─────────────────────────────────────────────────────────
            if (lower is "exit" or "quit" or "bye" or "goodbye")
                return ($"Goodbye, {Memory.Name}! Stay safe online. Remember: Think before you click! 🛡️",
                        sentiment, null);

            // ── Follow-up / conversation-flow triggers (Requirement 4) ────────
            if (IsFollowUp(lower))
            {
                if (Memory.LastBotResponse != null)
                {
                    string moreText = GetMoreDetails(Memory.LastTopic, Memory.Name);
                    return (sentimentPrefix + moreText, sentiment, Memory.LastTopic);
                }
                return ("I haven't told you anything yet! Ask me about a cybersecurity topic first.",
                        sentiment, null);
            }

            // ── Memory recall (Requirement 5) ─────────────────────────────────
            if (lower.Contains("remember") || lower.Contains("recall") ||
                lower.Contains("what do you know about me") || lower.Contains("my favourite"))
            {
                return (BuildMemoryRecall(), sentiment, null);
            }

            // ── Greetings ────────────────────────────────────────────────────
            if (lower.Contains("hello") || lower.Contains("hi ") || lower == "hi" ||
                lower.Contains("hey") || lower.Contains("good morning") || lower.Contains("good afternoon"))
            {
                string greeting = $"Hello, {Memory.Name}! Great to hear from you.\n" +
                                  "Ask me anything about cybersecurity — I'm here to help! 🛡️";
                if (Memory.FavouriteTopic != null)
                    greeting += $"\n\nBy the way, last time you were interested in {Memory.FavouriteTopic}. Want to continue?";
                return (sentimentPrefix + greeting, sentiment, null);
            }

            // ── How are you / purpose ────────────────────────────────────────
            if (lower.Contains("how are you") || lower.Contains("how do you do"))
                return ($"I'm running at full security protocols, {Memory.Name}! " +
                        "Always alert and ready to help keep you safe online.",
                        sentiment, null);

            if (lower.Contains("purpose") || lower.Contains("what do you do") ||
                lower.Contains("who are you") || lower.Contains("what are you"))
                return ($"I'm Cy-B-Ware, your cybersecurity awareness companion, {Memory.Name}!\n" +
                        "I can teach you about password safety, phishing scams, safe browsing, " +
                        "malware, 2FA, privacy, and more. Just ask!",
                        sentiment, null);

            if (lower.Contains("help") || lower.Contains("topics") ||
                lower.Contains("what can you") || lower.Contains("what can i ask"))
                return (GetTopicsHelp(), sentiment, null);

            // ── Cybersecurity topics ─────────────────────────────────────────
            if (lower.Contains("password") || lower.Contains("passphrase") || lower.Contains("credentials"))
            {
                Memory.RecordTopic("password safety");
                return (sentimentPrefix + Pick(_passwordResponses), sentiment, "password safety");
            }

            if (lower.Contains("phishing") || lower.Contains("phish") ||
                lower.Contains("fake email") || lower.Contains("suspicious email"))
            {
                Memory.RecordTopic("phishing");
                return (sentimentPrefix + Pick(_phishingResponses), sentiment, "phishing");
            }

            if (lower.Contains("scam") || lower.Contains("fraud") || lower.Contains("deception"))
            {
                Memory.RecordTopic("scams");
                return (sentimentPrefix + Pick(_scamResponses), sentiment, "scams");
            }

            if (lower.Contains("privacy") || lower.Contains("tracking") ||
                lower.Contains("data collection") || lower.Contains("footprint"))
            {
                Memory.RecordTopic("privacy");
                return (sentimentPrefix + Pick(_privacyResponses), sentiment, "privacy");
            }

            if (lower.Contains("malware") || lower.Contains("virus") ||
                lower.Contains("ransomware") || lower.Contains("spyware") ||
                lower.Contains("trojan") || lower.Contains("antivirus"))
            {
                Memory.RecordTopic("malware");
                return (sentimentPrefix + Pick(_malwareResponses), sentiment, "malware");
            }

            if (lower.Contains("browsing") || lower.Contains("browser") ||
                lower.Contains("internet") || lower.Contains("website") ||
                lower.Contains("https") || lower.Contains("vpn") ||
                lower.Contains("public wifi") || lower.Contains("safe online"))
            {
                Memory.RecordTopic("safe browsing");
                return (sentimentPrefix + Pick(_browsingResponses), sentiment, "safe browsing");
            }

            if (lower.Contains("two factor") || lower.Contains("2fa") ||
                lower.Contains("mfa") || lower.Contains("multi factor") ||
                lower.Contains("authenticator"))
            {
                Memory.RecordTopic("two-factor authentication");
                return (sentimentPrefix + Pick(_twoFaResponses), sentiment, "two-factor authentication");
            }

            if (lower.Contains("social engineering") || lower.Contains("pretexting") ||
                lower.Contains("vishing") || lower.Contains("smishing") ||
                lower.Contains("manipulation") || lower.Contains("impersonat"))
            {
                Memory.RecordTopic("social engineering");
                return (sentimentPrefix + Pick(_socialEngResponses), sentiment, "social engineering");
            }

            // ── Interest/topic detection for memory (Requirement 5) ───────────
            if (lower.Contains("interested in") || lower.Contains("i like") || lower.Contains("i love"))
            {
                foreach (var kw in new[] { "password", "phishing", "privacy", "malware",
                                            "browsing", "2fa", "social engineering", "scam" })
                {
                    if (lower.Contains(kw))
                    {
                        Memory.RecordTopic(kw);
                        return ($"Great! I'll remember that you're interested in {kw}. " +
                                $"It's a crucial part of staying safe online. " +
                                $"As someone interested in {kw}, you might want to ask me for tips on it!",
                                sentiment, kw);
                    }
                }
            }

            // ── Sentiment-only response (worried/frustrated with no keyword) ──
            if (sentiment == SentimentType.Worried)
                return (sentimentPrefix +
                        "Scammers and cybercriminals can be very convincing. " +
                        "The most important thing is that you're here learning how to protect yourself. " +
                        "Try asking me about a specific topic like passwords, phishing, or safe browsing.",
                        sentiment, null);

            if (sentiment == SentimentType.Frustrated)
                return (sentimentPrefix +
                        "Let's slow down and take it step by step. " +
                        "What specific cybersecurity topic would you like me to explain?",
                        sentiment, null);

            // ── Default / error handling (Requirement 7) ──────────────────────
            return ($"I'm not sure I understand that, {Memory.Name}. Could you rephrase? 🤔\n" +
                    "Try asking about: passwords, phishing, safe browsing, malware, " +
                    "2FA, privacy, or social engineering.",
                    sentiment, null);
        }

        // ── Helper: follow-up detection ───────────────────────────────────────
        private static bool IsFollowUp(string lower) =>
            lower.Contains("tell me more") || lower.Contains("explain more") ||
            lower.Contains("give me another") || lower.Contains("give me a tip") ||
            lower.Contains("more details") || lower.Contains("more info") ||
            lower.Contains("continue") || lower == "more";

        // ── Helper: more details per topic ────────────────────────────────────
        private string GetMoreDetails(string? topic, string name)
        {
            if (topic == null)
                return $"I'm not sure which topic to expand on, {name}. Could you specify?";

            return topic switch
            {
                "password safety" => Pick(_passwordResponses),
                "phishing"        => Pick(_phishingResponses),
                "scams"           => Pick(_scamResponses),
                "privacy"         => Pick(_privacyResponses),
                "malware"         => Pick(_malwareResponses),
                "safe browsing"   => Pick(_browsingResponses),
                "two-factor authentication" => Pick(_twoFaResponses),
                "social engineering" => Pick(_socialEngResponses),
                _ => $"Here's a follow-up tip on {topic}: always stay vigilant and " +
                     "verify sources before acting on any information online."
            };
        }

        // ── Helper: memory recall message ────────────────────────────────────
        private string BuildMemoryRecall()
        {
            var sb = new System.Text.StringBuilder();
            sb.AppendLine($"Here's what I know about you, {Memory.Name}:");
            sb.AppendLine($"• Name: {Memory.Name}");

            if (Memory.FavouriteTopic != null)
                sb.AppendLine($"• Most interested in: {Memory.FavouriteTopic}");

            if (Memory.LastTopic != null)
                sb.AppendLine($"• Last topic discussed: {Memory.LastTopic}");

            if (Memory.TopicFrequency.Count > 0)
            {
                sb.AppendLine("• Topics explored:");
                foreach (var kv in Memory.TopicFrequency.OrderByDescending(x => x.Value))
                    sb.AppendLine($"   – {kv.Key} ({kv.Value}x)");
            }

            if (Memory.FavouriteTopic != null)
                sb.AppendLine($"\nAs someone interested in {Memory.FavouriteTopic}, " +
                              "you might want to review the security settings on your accounts.");

            return sb.ToString();
        }

        // ── Helper: topics help text ─────────────────────────────────────────
        private static string GetTopicsHelp() =>
            "Here are the topics I can help you with:\n\n" +
            "🔑 Password Safety\n" +
            "🎣 Phishing Awareness\n" +
            "🌐 Safe Browsing\n" +
            "🔐 Two-Factor Authentication (2FA)\n" +
            "🦠 Malware & Viruses\n" +
            "🎭 Social Engineering\n" +
            "🕵️ Privacy & Data Protection\n" +
            "⚠️  Scams & Fraud\n\n" +
            "Just type a topic or ask a question naturally!";
    }
}
